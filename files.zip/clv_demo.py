import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta

# Set style
sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (14, 10)

# Generate synthetic e-commerce data
np.random.seed(42)

# Parameters
n_customers = 1000
start_date = datetime(2022, 1, 1)
end_date = datetime(2024, 12, 31)

# Customer acquisition dates (more customers acquired early)
acquisition_dates = [
    start_date + timedelta(days=int(x)) 
    for x in np.random.exponential(scale=200, size=n_customers)
]
acquisition_dates = [d if d < end_date else end_date for d in acquisition_dates]

# Generate transaction data
transactions = []
customer_id = 1

for acq_date in acquisition_dates:
    # Customer characteristics
    base_purchase_rate = np.random.gamma(2, 2)  # purchases per month
    base_order_value = np.random.gamma(50, 2)  # average order value
    churn_prob_monthly = np.random.beta(2, 20)  # monthly churn probability
    
    current_date = acq_date
    active = True
    
    while active and current_date < end_date:
        # Decide if customer churns this month
        if np.random.random() < churn_prob_monthly:
            active = False
            break
        
        # Number of purchases this month
        n_purchases = np.random.poisson(base_purchase_rate)
        
        for _ in range(n_purchases):
            # Random day in the month
            days_offset = np.random.randint(0, 30)
            purchase_date = current_date + timedelta(days=days_offset)
            
            if purchase_date <= end_date:
                # Order value with some variation
                order_value = base_order_value * np.random.lognormal(0, 0.3)
                
                transactions.append({
                    'customer_id': customer_id,
                    'acquisition_date': acq_date,
                    'transaction_date': purchase_date,
                    'order_value': order_value
                })
        
        current_date += timedelta(days=30)
    
    customer_id += 1

# Create DataFrame
df = pd.DataFrame(transactions)
df['acquisition_date'] = pd.to_datetime(df['acquisition_date'])
df['transaction_date'] = pd.to_datetime(df['transaction_date'])

# Add cost structure (70% margin)
df['gross_margin'] = 0.70
df['profit'] = df['order_value'] * df['gross_margin']

print(f"Generated {len(df)} transactions for {n_customers} customers")
print(f"\nData sample:")
print(df.head(10))

# ============================================================================
# CLV CALCULATIONS
# ============================================================================

# 1. HISTORIC CLV (what customers have already generated)
historic_clv = df.groupby('customer_id').agg({
    'profit': 'sum',
    'order_value': 'sum',
    'transaction_date': 'count'
}).rename(columns={'transaction_date': 'n_transactions'})

historic_clv.columns = ['total_profit', 'total_revenue', 'n_transactions']

print("\n" + "="*60)
print("HISTORIC CLV (Past Performance)")
print("="*60)
print(f"Average historic CLV: ${historic_clv['total_profit'].mean():.2f}")
print(f"Median historic CLV: ${historic_clv['total_profit'].median():.2f}")
print(f"Top 10% average CLV: ${historic_clv['total_profit'].quantile(0.9):.2f}")

# 2. COHORT-BASED ANALYSIS
# Group customers by acquisition month
df['cohort_month'] = df['acquisition_date'].dt.to_period('M')
df['transaction_month'] = df['transaction_date'].dt.to_period('M')

# Calculate months since acquisition
df['months_since_acquisition'] = (
    (df['transaction_month'] - df['cohort_month']).apply(lambda x: x.n)
)

# Cohort analysis
cohort_data = df.groupby(['cohort_month', 'months_since_acquisition']).agg({
    'customer_id': 'nunique',
    'profit': 'sum'
}).rename(columns={'customer_id': 'active_customers', 'profit': 'cohort_profit'})

# Get cohort sizes (month 0)
cohort_sizes = df[df['months_since_acquisition'] == 0].groupby('cohort_month')['customer_id'].nunique()

# Calculate retention rate for each cohort/month
cohort_data = cohort_data.reset_index()
cohort_data['cohort_size'] = cohort_data['cohort_month'].map(cohort_sizes)
cohort_data['retention_rate'] = cohort_data['active_customers'] / cohort_data['cohort_size']
cohort_data['avg_profit_per_active'] = cohort_data['cohort_profit'] / cohort_data['active_customers']

print("\n" + "="*60)
print("COHORT RETENTION RATES")
print("="*60)
print(cohort_data.head(20))

# 3. PREDICTIVE CLV using Gupta & Lehmann formula
# CLV = M * (r / (1 + d - r))
# Where: M = avg profit per period, r = retention rate, d = discount rate

# Calculate average monthly retention rate (across all cohorts, months 1-12)
retention_data = cohort_data[
    (cohort_data['months_since_acquisition'] >= 1) & 
    (cohort_data['months_since_acquisition'] <= 12)
]
avg_retention_rate = retention_data['retention_rate'].mean()

# Average monthly profit per active customer
avg_monthly_profit = retention_data['avg_profit_per_active'].mean()

# Discount rate (annual 12% -> monthly ~1%)
monthly_discount_rate = 0.01

# Predictive CLV using retention formula
predictive_clv = avg_monthly_profit * (
    avg_retention_rate / (1 + monthly_discount_rate - avg_retention_rate)
)

print("\n" + "="*60)
print("PREDICTIVE CLV (Gupta & Lehmann Formula)")
print("="*60)
print(f"Average monthly retention rate: {avg_retention_rate:.2%}")
print(f"Average monthly profit per customer: ${avg_monthly_profit:.2f}")
print(f"Monthly discount rate: {monthly_discount_rate:.2%}")
print(f"\nPredictive CLV per customer: ${predictive_clv:.2f}")
print(f"Historic average CLV: ${historic_clv['total_profit'].mean():.2f}")
print(f"\nDifference: Predictive accounts for future value beyond observation period")

# ============================================================================
# VISUALIZATIONS
# ============================================================================

fig = plt.figure(figsize=(16, 12))

# 1. Distribution of Historic CLV
ax1 = plt.subplot(3, 3, 1)
historic_clv['total_profit'].hist(bins=50, edgecolor='black', alpha=0.7)
plt.axvline(historic_clv['total_profit'].mean(), color='red', linestyle='--', 
            label=f'Mean: ${historic_clv["total_profit"].mean():.2f}')
plt.axvline(historic_clv['total_profit'].median(), color='green', linestyle='--',
            label=f'Median: ${historic_clv["total_profit"].median():.2f}')
plt.xlabel('Historic CLV ($)')
plt.ylabel('Number of Customers')
plt.title('Distribution of Historic CLV')
plt.legend()
plt.grid(alpha=0.3)

# 2. CLV by Number of Transactions
ax2 = plt.subplot(3, 3, 2)
plt.scatter(historic_clv['n_transactions'], historic_clv['total_profit'], 
            alpha=0.5, s=30)
plt.xlabel('Number of Transactions')
plt.ylabel('Historic CLV ($)')
plt.title('CLV vs Transaction Frequency')
plt.grid(alpha=0.3)

# 3. Cohort Retention Heatmap
ax3 = plt.subplot(3, 3, 3)
# Pivot for heatmap (show first 12 cohorts, first 12 months)
retention_pivot = cohort_data.pivot_table(
    values='retention_rate',
    index='cohort_month',
    columns='months_since_acquisition'
)
retention_pivot = retention_pivot.iloc[:12, :12]  # First 12 cohorts and months

sns.heatmap(retention_pivot, annot=True, fmt='.1%', cmap='RdYlGn', 
            cbar_kws={'label': 'Retention Rate'}, vmin=0, vmax=1)
plt.title('Cohort Retention Rates')
plt.xlabel('Months Since Acquisition')
plt.ylabel('Acquisition Cohort')

# 4. Average Retention Curve
ax4 = plt.subplot(3, 3, 4)
avg_retention_by_month = cohort_data.groupby('months_since_acquisition')['retention_rate'].mean()
plt.plot(avg_retention_by_month.index, avg_retention_by_month.values, 
         marker='o', linewidth=2, markersize=6)
plt.xlabel('Months Since Acquisition')
plt.ylabel('Average Retention Rate')
plt.title('Average Customer Retention Over Time')
plt.grid(alpha=0.3)
plt.axhline(y=avg_retention_rate, color='red', linestyle='--', 
            label=f'Avg (months 1-12): {avg_retention_rate:.1%}')
plt.legend()

# 5. Revenue per Active Customer by Cohort Age
ax5 = plt.subplot(3, 3, 5)
avg_profit_by_month = cohort_data.groupby('months_since_acquisition')['avg_profit_per_active'].mean()
plt.plot(avg_profit_by_month.index, avg_profit_by_month.values,
         marker='o', linewidth=2, markersize=6, color='green')
plt.xlabel('Months Since Acquisition')
plt.ylabel('Avg Monthly Profit ($)')
plt.title('Average Monthly Profit per Active Customer')
plt.grid(alpha=0.3)
plt.axhline(y=avg_monthly_profit, color='red', linestyle='--',
            label=f'Overall Avg: ${avg_monthly_profit:.2f}')
plt.legend()

# 6. Customer Segmentation by Value
ax6 = plt.subplot(3, 3, 6)
# Create segments based on historic CLV
historic_clv['segment'] = pd.qcut(historic_clv['total_profit'], 
                                   q=4, 
                                   labels=['Low', 'Medium', 'High', 'VIP'])
segment_counts = historic_clv['segment'].value_counts().sort_index()
colors = ['#ff6b6b', '#ffd93d', '#6bcf7f', '#4d96ff']
plt.bar(segment_counts.index, segment_counts.values, color=colors, edgecolor='black')
plt.xlabel('Customer Segment')
plt.ylabel('Number of Customers')
plt.title('Customer Segmentation by Historic CLV')
plt.grid(alpha=0.3, axis='y')

# Add value labels
for i, v in enumerate(segment_counts.values):
    plt.text(i, v + 5, str(v), ha='center', fontweight='bold')

# 7. CLV Comparison: Historic vs Predictive
ax7 = plt.subplot(3, 3, 7)
comparison_data = {
    'Historic\nCLV\n(Actual)': historic_clv['total_profit'].mean(),
    'Predictive\nCLV\n(G&L Formula)': predictive_clv
}
bars = plt.bar(comparison_data.keys(), comparison_data.values(), 
               color=['#3498db', '#e74c3c'], edgecolor='black', width=0.6)
plt.ylabel('Average CLV ($)')
plt.title('CLV Methodology Comparison')
plt.grid(alpha=0.3, axis='y')

# Add value labels
for bar in bars:
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2., height,
             f'${height:.2f}', ha='center', va='bottom', fontweight='bold')

# 8. Cumulative Revenue by Cohort
ax8 = plt.subplot(3, 3, 8)
# Calculate cumulative profit by months since acquisition
cumulative_profit = cohort_data.groupby('months_since_acquisition')['avg_profit_per_active'].mean().cumsum()
plt.plot(cumulative_profit.index, cumulative_profit.values, 
         linewidth=3, color='purple', marker='o', markersize=5)
plt.xlabel('Months Since Acquisition')
plt.ylabel('Cumulative Profit ($)')
plt.title('Average Cumulative Profit per Customer')
plt.grid(alpha=0.3)
plt.fill_between(cumulative_profit.index, 0, cumulative_profit.values, alpha=0.3, color='purple')

# 9. Key Metrics Summary
ax9 = plt.subplot(3, 3, 9)
ax9.axis('off')
metrics_text = f"""
KEY METRICS SUMMARY
{'='*40}

HISTORIC PERFORMANCE:
  • Total Customers: {n_customers:,}
  • Total Transactions: {len(df):,}
  • Avg Historic CLV: ${historic_clv['total_profit'].mean():.2f}
  • Median Historic CLV: ${historic_clv['total_profit'].median():.2f}
  
RETENTION ANALYSIS:
  • Avg Monthly Retention: {avg_retention_rate:.1%}
  • Avg Monthly Profit: ${avg_monthly_profit:.2f}
  
PREDICTIVE CLV:
  • Gupta & Lehmann Formula: ${predictive_clv:.2f}
  • Discount Rate (monthly): {monthly_discount_rate:.1%}
  
CUSTOMER SEGMENTS:
  • Low Value: {segment_counts['Low']} customers
  • Medium Value: {segment_counts['Medium']} customers
  • High Value: {segment_counts['High']} customers
  • VIP: {segment_counts['VIP']} customers
"""
plt.text(0.1, 0.9, metrics_text, transform=ax9.transAxes,
         fontsize=10, verticalalignment='top', fontfamily='monospace',
         bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/clv_analysis.png', dpi=300, bbox_inches='tight')
print("\n" + "="*60)
print("Visualization saved to clv_analysis.png")
print("="*60)

# ============================================================================
# DETAILED BREAKDOWN BY SEGMENT
# ============================================================================

print("\n" + "="*60)
print("CUSTOMER SEGMENT ANALYSIS")
print("="*60)

segment_analysis = historic_clv.groupby('segment').agg({
    'total_profit': ['mean', 'median', 'sum'],
    'n_transactions': 'mean',
    'total_revenue': 'mean'
})

segment_analysis.columns = ['_'.join(col) for col in segment_analysis.columns]
segment_analysis['pct_total_profit'] = (
    segment_analysis['total_profit_sum'] / segment_analysis['total_profit_sum'].sum() * 100
)

print(segment_analysis)

print("\n" + "="*60)
print("INTERPRETATION")
print("="*60)
print(f"""
1. HISTORIC CLV: Average customer has generated ${historic_clv['total_profit'].mean():.2f}
   - This is PAST performance only
   - Doesn't predict future value

2. RETENTION RATE: {avg_retention_rate:.1%} monthly retention
   - This means ~{(1-avg_retention_rate)*100:.1f}% churn per month
   - Annual retention: ~{(avg_retention_rate**12)*100:.1f}%

3. PREDICTIVE CLV: ${predictive_clv:.2f} per customer
   - Uses retention formula to project future value
   - Accounts for discounting (time value of money)
   - More useful for decision-making than historic CLV

4. TOP INSIGHT: Top 25% (VIP) customers generate 
   {segment_analysis.loc['VIP', 'pct_total_profit']:.1f}% of total profit
   - Focus retention efforts here
   - Different strategies for different segments
""")

plt.show()
